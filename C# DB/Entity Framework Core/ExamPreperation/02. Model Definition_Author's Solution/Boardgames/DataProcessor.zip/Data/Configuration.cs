﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-FE75MLC\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
