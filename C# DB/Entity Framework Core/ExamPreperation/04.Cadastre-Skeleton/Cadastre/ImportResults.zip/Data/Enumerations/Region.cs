﻿namespace Cadastre.Data.Enumerations;

public enum Region
{
    SouthEast,
    SouthWest,
    NorthEast,
    NorthWest,
}