﻿using Cadastre.Data;

namespace Cadastre.DataProcessor
{
    public class Serializer
    {
        public static string ExportPropertiesWithOwners(CadastreContext dbContext)
        {
           throw new NotImplementedException();
        }

        public static string ExportFilteredPropertiesWithDistrict(CadastreContext dbContext)
        {
            throw new NotImplementedException();
        }
    }
}
