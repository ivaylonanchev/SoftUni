﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"";
    }
}
