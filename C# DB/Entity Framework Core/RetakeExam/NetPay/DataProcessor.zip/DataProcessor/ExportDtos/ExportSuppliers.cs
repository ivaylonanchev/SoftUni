﻿using System.Globalization;

namespace NetPay.DataProcessor.ExportDtos;

public class ExportSuppliers
{
    public string SupplierName { get; set; }
}