﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-FE75MLC\\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
