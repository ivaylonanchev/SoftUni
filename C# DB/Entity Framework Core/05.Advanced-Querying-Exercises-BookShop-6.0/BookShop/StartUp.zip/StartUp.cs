﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System.Runtime.Serialization;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            if (!Enum.TryParse(command, true, out AgeRestriction ageRestriction))
            {
                return string.Empty;
            }

            var bookTitles = context.Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToArray();

            //var bookTitles = context.Books
            //    .AsEnumerable()
            //    .Where(b => b.AgeRestriction.ToString().ToLower() == command.ToLower())
            //    .Select(b => b.Title)
            //    .OrderBy(t => t)
            //    .ToArray();

            return string.Join(Environment.NewLine, bookTitles);
        }
    }
}


