﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-FE75MLC\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
