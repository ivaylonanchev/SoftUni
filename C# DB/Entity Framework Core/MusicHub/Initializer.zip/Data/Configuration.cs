﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-FE75MLC\\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
