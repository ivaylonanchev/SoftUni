﻿namespace SharkTaxonomy
{
    public class Shark
    {
    }
}
