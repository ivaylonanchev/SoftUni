﻿namespace SharkTaxonomy
{
    public class Classifier
    {

    }
}
